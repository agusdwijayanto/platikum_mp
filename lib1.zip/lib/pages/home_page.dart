import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Halaman Utama', style: TextStyle(fontSize: 18)),
    );
  }
}
